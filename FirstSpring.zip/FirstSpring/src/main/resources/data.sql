insert into Subscriber(id,fname,lname,email)
values ('170049','Sadia','Islam','sadia@gmail.com');
insert into Subscriber(id,fname,lname,email)
values('170059','Easin','Ahmed','easin@gmail.com');
insert into Subscriber(id,fname,lname,email)
values ('170058','Tuno','Ahmed','tuno@gmail.com');
insert into Subscriber(id,fname,lname,email)
values('170085','Ibrahim','Munna','munna@gmail.com');
commit ;
