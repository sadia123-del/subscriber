package weiredrtn.demo.Domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class SubscriberController {
    @Autowired
    SubscriberRepository subscriberRepository;

    @GetMapping(value = "/sub")
    public ResponseEntity<List<Subscriber>>getAllSubscribers(){
        List<Subscriber> subcribers=subscriberRepository.findAll();
        return new ResponseEntity<List<Subscriber>>(subcribers,new HttpHeaders(), HttpStatus.OK);
    }
}
